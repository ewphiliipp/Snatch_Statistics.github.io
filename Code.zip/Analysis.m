%% === Datenanalyse für Snatch-Videos ===
clc; clear; close all;

%% 1. Daten laden
filename = "Snatch_39.csv";  
trialidx_str = regexp(filename, '(\d+)', 'match');  
trialidx = str2double(trialidx_str{1});  

data = readtable(filename);
meta_data = readtable("Info.csv");

%% 2. Datenvorverarbeitung mit Butterworth-Filter
fs = 30;                    % Abtastrate (30 Frames/Sekunde)
fc = 5;                      % Cutoff-Frequenz (Hz) – Anpassbar je nach Bewegungscharakteristik
order = 4;                   % Filterordnung (höher = steilere Flanke)

% Butterworth-Tiefpassfilter erstellen
[b, a] = butter(order, fc/(fs/2), 'low');

%% 2. Datenvorverarbeitung
% Marker-Daten filtern (statt smooth)
x = filtfilt(b, a, data.Markierung1_0_X); % Zero-phase filtering
y = filtfilt(b, a, data.Markierung1_0_Y);

% Gelenkpositionen filtern
knee = [filtfilt(b, a, data.Markierung2_0_X), filtfilt(b, a, data.Markierung2_0_Y)];
hip = [filtfilt(b, a, data.Markierung3_0_X), filtfilt(b, a, data.Markierung3_0_Y)];
shoulder = [filtfilt(b, a, data.Markierung4_0_X), filtfilt(b, a, data.Markierung4_0_Y)];

frames = (1:length(x))';

%% 3. Normalisierung auf 100 Frames
original_frames = frames;
target_frames = linspace(1, length(x), 100)';

% Interpolation aller Variablen
x_norm = interp1(original_frames, x, target_frames, 'pchip');
y_norm = interp1(original_frames, y, target_frames, 'pchip');
knee_norm = interp1(original_frames, knee, target_frames, 'pchip');
hip_norm = interp1(original_frames, hip, target_frames, 'pchip');
shoulder_norm = interp1(original_frames, shoulder, target_frames, 'pchip');

%% 4. Kinematische Berechnungen
% Geschwindigkeit und Beschleunigung
dt = mean(diff(target_frames));
speed_norm = gradient(y_norm, dt);
acceleration_norm = gradient(speed_norm, dt);

% Kraftberechnung
mass = meta_data.x1rm(trialidx) / meta_data.percentage(trialidx) * 100;
g = 9.81;
Force_norm = mass * (acceleration_norm + g);
rel_force_norm = Force_norm / meta_data.x1rm(trialidx);

% Hüftwinkel
hip_angle_norm = zeros(100, 1);
for i = 1:100
    a = norm(shoulder_norm(i,:) - knee_norm(i,:));
    b = norm(hip_norm(i,:) - knee_norm(i,:));
    c = norm(hip_norm(i,:) - shoulder_norm(i,:));
    hip_angle_norm(i) = acosd((b^2 + c^2 - a^2) / (2 * b * c));
end
hip_angle_norm = smooth(hip_angle_norm, 3);

%% 5. Phasenerkennung (korrigierte Version)
% Original-Phasen
diff_bar_knee = y_norm - knee_norm(:,2);
[~, t_start_SP] = min(abs(diff_bar_knee));
diff_bar_hip = y_norm - hip_norm(:,2);
[~, t_start_TP] = min(abs(diff_bar_hip));
[~, t_start_TO] = max(hip_angle_norm);
[~, t_rec] = min(shoulder_norm(t_start_TO:end,2));
t_start_R = t_start_TO + t_rec - 1;

%% 6. Visualisierung
% Trajektorie
figure('Name', 'Stangentrajektorie');
plot(x_norm, y_norm, 'b-', 'LineWidth', 1.5); 
hold on; grid on;
plot(x_norm(1), y_norm(1), 'ro', 'MarkerSize', 8);
plot(x_norm(end), y_norm(end), 'go', 'MarkerSize', 8);
xlabel('X Position (normiert)'); ylabel('Y Position (normiert)');
title('Normalisierte Stangentrajektorie (100 Frames)');
legend('Trajektorie', 'Start', 'Ende');
axis equal;

% Kraftprofil
figure('Name', 'Kraftverlauf');
plot(rel_force_norm, 'g-', 'LineWidth', 1.5);
xlabel('Normierte Zeit (Frames)'); ylabel('Kraft / 1RM');
title('Relatives Kraftprofil');
grid on;

% Gelenkwinkel
figure('Name', 'Hüftwinkel');
plot(hip_angle_norm, 'm-', 'LineWidth', 1.5);
xlabel('Normierte Zeit (Frames)'); ylabel('Winkel (°)');
title('Hüftwinkelverlauf');
grid on;

%% 7. Daten speichern
% Feature-Tabelle
features = [
    target_frames, ...
    x_norm, y_norm, ...
    knee_norm, hip_norm, shoulder_norm, ...
    hip_angle_norm, ...
    rel_force_norm  
];

% Variablennamen
var_names = {
    'Frame', 'Bar_X_norm', 'Bar_Y_norm', ...
    'Knee_X_norm', 'Knee_Y_norm', 'Hip_X_norm', 'Hip_Y_norm', ...
    'Shoulder_X_norm', 'Shoulder_Y_norm', 'Hip_Angle', 'Relative_Force'
};

% CSV-Export
output_filename = sprintf('Snatch_features_%02d.csv', trialidx);
writetable(array2table(features, 'VariableNames', var_names), output_filename);
fprintf('Daten erfolgreich gespeichert unter: %s\n', output_filename);

%% 8. Konsolenausgabe
fprintf('\n=== Phasenübergänge ===\n');
fprintf('1. First Pull: 1-%d\n', t_start_SP);
fprintf('2. Second Pull: %d-%d\n', t_start_SP+1, t_start_TP);
fprintf('3. Third Pull: %d-%d\n', t_start_TP+1, t_start_TO);
fprintf('4. Turnover: %d-%d\n', t_start_TO+1, t_start_R);
fprintf('5. Recovery: %d-100\n', t_start_R+1);