%% 1. Daten laden und vorbereiten
files = dir('Snatch_features_*.csv');
num_files = length(files);
all_data = cell(num_files, 1);

for i = 1:num_files
    all_data{i} = readtable(files(i).name);
end

time_steps = 100;
time_norm = linspace(0, 100, time_steps)';

%% 2. Mittelwerte berechnen
vars = {'Bar_X_norm', 'Bar_Y_norm', 'Knee_X_norm', 'Knee_Y_norm', ...
        'Hip_X_norm', 'Hip_Y_norm', 'Shoulder_X_norm', 'Shoulder_Y_norm', ...
        'Hip_Angle', 'Relative_Force'};

mean_data = struct();
for v = 1:length(vars)
    var_data = zeros(time_steps, num_files);
    for i = 1:num_files
        var_data(:,i) = all_data{i}.(vars{v});
    end
    mean_data.(vars{v}) = mean(var_data, 2);
end

%% 3. Statische Plots
figure('Position', [100 100 800 600])

subplot(2,1,1)
plot(time_norm, mean_data.Relative_Force, 'b-', 'LineWidth', 2)
title('Durchschnittliches Kraftprofil')
ylabel('Relative Kraft')
grid on

subplot(2,1,2)
plot(time_norm, mean_data.Hip_Angle, 'm-', 'LineWidth', 2)
title('Hüftwinkelverlauf')
xlabel('Bewegungsfortschritt (%)')
ylabel('Winkel (Grad)')
grid on

%% 4. Animation mit Videoaufzeichnung
fig = figure('Position', [200 200 800 700], 'Renderer', 'opengl');
ax = axes('Parent', fig);
hold(ax, 'on')
grid(ax, 'on')
axis(ax, 'equal')
title(ax, 'Durchschnittliche Snatch-Bewegung')

% Achsenlimits
all_x = [mean_data.Knee_X_norm; mean_data.Hip_X_norm; mean_data.Shoulder_X_norm; mean_data.Bar_X_norm];
all_y = [mean_data.Knee_Y_norm; mean_data.Hip_Y_norm; mean_data.Shoulder_Y_norm; mean_data.Bar_Y_norm];
xlim([min(all_x)-0.1, max(all_x)+0.1])
ylim([min(all_y)-0.1, max(all_y)+0.1])

% Statischer Hintergrundpfad
plot(mean_data.Bar_X_norm, mean_data.Bar_Y_norm, 'k-', 'LineWidth', 1, 'Color', [0.5 0.5 0.5])

% Animationselemente
body_line = plot(ax, NaN, NaN, 'b-', 'LineWidth', 3);
current_path = plot(ax, NaN, NaN, 'k-', 'LineWidth', 2);
knee_marker = plot(ax, NaN, NaN, 'ro', 'MarkerSize', 12, 'MarkerFaceColor', 'r');
hip_marker = plot(ax, NaN, NaN, 'go', 'MarkerSize', 12, 'MarkerFaceColor', 'g');
shoulder_marker = plot(ax, NaN, NaN, 'bo', 'MarkerSize', 12, 'MarkerFaceColor', 'b');
barbell_marker = plot(ax, NaN, NaN, 'ko', 'MarkerSize', 12, 'MarkerFaceColor', 'k');

progress_text = text(ax, 0.02, 0.95, '', 'Units', 'normalized', ...
                    'BackgroundColor', 'w', 'FontSize', 12);

%% Videoaufzeichnung starten
v = VideoWriter('snatch_animation.mp4', 'MPEG-4');
v.FrameRate = 20; % 20 Frames pro Sekunde
v.Quality = 90;   % Qualität (0-100)
open(v);

%% Animationsloop
for frame = 1:time_steps
    % Körperhaltung aktualisieren
    set(body_line, 'XData', [mean_data.Knee_X_norm(frame), mean_data.Hip_X_norm(frame), mean_data.Shoulder_X_norm(frame)], ...
                   'YData', [mean_data.Knee_Y_norm(frame), mean_data.Hip_Y_norm(frame), mean_data.Shoulder_Y_norm(frame)]);
    
    % Langhantelpfad
    set(current_path, 'XData', mean_data.Bar_X_norm(1:frame), ...
                      'YData', mean_data.Bar_Y_norm(1:frame));
    
    % Markerpositionen
    set(knee_marker, 'XData', mean_data.Knee_X_norm(frame), 'YData', mean_data.Knee_Y_norm(frame));
    set(hip_marker, 'XData', mean_data.Hip_X_norm(frame), 'YData', mean_data.Hip_Y_norm(frame));
    set(shoulder_marker, 'XData', mean_data.Shoulder_X_norm(frame), 'YData', mean_data.Shoulder_Y_norm(frame));
    set(barbell_marker, 'XData', mean_data.Bar_X_norm(frame), 'YData', mean_data.Bar_Y_norm(frame));
    
    % Fortschrittsanzeige
    set(progress_text, 'String', sprintf('Frame: %d/%d (%.1f%%)', frame, time_steps, time_norm(frame)));
    
    % Frame aufnehmen
    writeVideo(v, getframe(fig));
    
    % Kurze Pause für Echtzeitanzeige
    if ~isempty(get(groot, 'CurrentFigure')) % Nur pausieren, wenn Figur sichtbar ist
        pause(0.02);
    end
end

%% Videoaufzeichnung abschließen
close(v);
disp('Video erfolgreich gespeichert als: snatch_animation.mp4');